# Aiversecity local review build

Code revision: 9bbdc75 (codex/trend-evidence-submission). Prepared 23 October 2026 MYT.
This package includes the tested production client build, its server/API source, locked install files and original license notices. No dependencies, credentials or personal profiles are included. It is a local build, not a public deployment or Replit-use proof.

Use Node.js 22.12+ or 24. Extract this ZIP, open its folder in a terminal, then run:

npm run setup
npm --prefix frontend run preview -- --host 127.0.0.1 --port 4176 --strictPort

Open http://127.0.0.1:4176/ . The Vite preview runs the fixed BLS and official RSS endpoints as well as the compiled client. A static-only file server cannot run those endpoints. Network access is needed for installation, hosted fonts and source refresh; dated snapshots/fallbacks and no-evidence states remain explicit. Use only a fictional alias and synthetic answers. Answers and progress stay in browser memory and clear on reload. No runtime LLM, database or GPU is used.

To rebuild from the included source: npm run typecheck, npm test, npm run build. For browser checks install Chromium with npx --prefix frontend playwright install chromium, then npm run test:e2e. Use the source repository for review history and the submission checklist for final access/platform obligations.

Build provenance: source-manifest.json lists the frontend inputs used in final clean-install verification, with SHA-256 hashes. The pre-existing untracked user file Evidence 2.tsx is intentionally absent. Original project code is Apache-2.0; third-party and font notices are under docs/licenses. Design provenance still needs team confirmation before public release.

The 35% BLS projection is a U.S. related-role proxy, not Malaysian hiring demand. Exploration order can change under the documented dated proxy policy while capability scores retain their meaning. News is context. There are no real user research, employment outcomes or measured skill-demand forecasts.
